classdef descFourier
    %DESCFOURIER Descripteur de forme de Fourier
    %   calcule le contour de la forme, et retourne
    %   sa transform�e de Fourier normalis�e
    
    properties (Constant = true)
        nbPoints = 128; % nombre de points du contour
        descSize = 16; % fr�quences du spectre � conserver
    end
    
    properties
       values; % spectre du contour (taille 'nbFreq') 
    end
    
    methods
         % constructeur (� partir d'une image blanche sur noire)
         function dst = descFourier(shape)
             
            % Vous pouvez utiliser les fonctions matlab :
            % bwtraceboundary, interp1, etc..
            imshow(shape,[]);
            P = [0 0]
            flag = 0;
            for i=1:256
                for j=1:256
                    if(shape(i,j)~=0)
                        P(1) = i;
                        P(2) = j;
                        flag = 1;
                        break;
                    end
                end
                if(flag == 1)
                    break;
                end
            end
            contour = bwtraceboundary(shape,P,'E');
            contour(:,1) = 256 - contour(:,1);
            %plot( contour(:,2), contour(:,1)); % X premi�re colonne, Y deuxi�me
            [m,n] = size(contour);
            contourInterp = interp1(1:m,contour,linspace(1,m,descFourier.nbPoints));
            plot(contourInterp(:,2), contourInterp(:,1));
            % TODO Question 1 :
            fourierContour = abs(fft(contourInterp(:,2)+ i*contourInterp(:,1)));
            fourierContour = fourierContour(2:128) % Invariance translation
            fourierContour = fourierContour/fourierContour(1); % Invariance �chelle
            dst.values = zeros(1,descFourier.descSize);
            dst.values = fourierContour(1:descFourier.descSize);
            
         end
         
         % distance entre deux descripteurs
        function d = distance(desc1, desc2)
           
            d = mean(abs(desc1.values - desc2.values));
        end
    end
    
end

